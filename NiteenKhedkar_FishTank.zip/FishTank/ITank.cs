﻿using System;
using System.Collections.Generic;

namespace FishTank
{
    public interface ITank
    {
        List<string> Feed();
        string Save(FishDetail fishDetailObj);
    }
}
