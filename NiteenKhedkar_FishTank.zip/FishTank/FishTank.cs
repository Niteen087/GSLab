﻿using System;
using System.Collections.Generic;

namespace FishTank
{
    public class FishTank:Tank
    {
        public ITank tankService;
        public FishTank(ITank _tankService)
        {
            tankService = _tankService;
        }

        public override List<string> Feed()
        {
            return tankService.Feed();
        }
        public override string Save(FishDetail fishDetailObj)
        {
            return tankService.Save(fishDetailObj);
        }
    }
}
