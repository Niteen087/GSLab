﻿using System;
using System.Collections.Generic;

namespace FishTank
{
    public abstract class Tank
    {
        public abstract List<string> Feed();
        public abstract string Save(FishDetail fishDetailObj);
    }
}
