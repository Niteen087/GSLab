﻿
namespace FishTank
{
    public class FishDetail
    {
        public string Name { get; set; }
        public string RequiredFood { get; set; }
    }
}
