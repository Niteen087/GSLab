﻿using System;
using System.Collections.Generic;
using System.Xml;

namespace FishTank
{
    public class Food:ITank
    {
        public List<string> Feed()
        {
            return GetFishDetails();
        }
        public string Save(FishDetail fish)
        {
            return SaveFishDetails(fish);
        }

        private string SaveFishDetails(FishDetail fishDetail)
        {
            XmlDocument XmlDocObj = new XmlDocument();
            string returnMsg = string.Empty;

            try
            {
                XmlDocObj.Load(@"FishDetailsXML.xml");
                var RootNode = XmlDocObj.SelectSingleNode("FishDetails");
                XmlNode fishNode = RootNode.AppendChild(XmlDocObj.CreateNode(XmlNodeType.Element, "Fish", ""));
                fishNode.AppendChild(XmlDocObj.CreateNode(XmlNodeType.Element, "name", "")).InnerText = fishDetail.Name;
                fishNode.AppendChild(XmlDocObj.CreateNode(XmlNodeType.Element, "requiredfood", "")).InnerText = fishDetail.RequiredFood;
                XmlDocObj.Save(@"FishDetailsXML.xml");
                returnMsg= "Record Added Sucessfully";
            }
            catch(Exception ex)
            {
                returnMsg = ex.Message;
            }

            return returnMsg;
        }

        private List<string> GetFishDetails()
        {
            XmlDocument XmlDocObj = new XmlDocument();
            List<string> foodVolum = new List<string>();
            string retVal = string.Empty;

            try
            {
                XmlDocObj.Load(@"FishDetailsXML.xml");
                var RootNode = XmlDocObj.SelectNodes("FishDetails");

                foreach (XmlNode parentNode in RootNode)
                {
                    foreach (XmlNode childNode in parentNode)
                    {
                        if (childNode.HasChildNodes)
                        {
                            if (childNode.ChildNodes[1].Name == "requiredfood")
                            {
                                retVal = childNode.ChildNodes[1].InnerText;
                            }

                            if (childNode.ChildNodes[0].Name == "name")
                            {
                                retVal += " for each " + childNode.ChildNodes[0].InnerText;
                            }
                        }
                        foodVolum.Add(retVal);
                    }
                }
            }
            catch(Exception ex)
            {
                throw;
            }

            return foodVolum;
        }

    }
}
